package com.example.myapplication

import android.Manifest
import android.app.DownloadManager.Request
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.service.controls.ControlsProviderService.TAG
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.myapplication.databinding.ActivityMapsBinding
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.util.FileUtil.delete
import com.google.firebase.ktx.Firebase

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    companion object{
        const val REQUEST_CODE_LOCATION = 0
    }
    //var long_data = findViewById<EditText>(R.id.data_longitu)
    //var lat_data = findViewById<EditText>(R.id.data_latitud)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_maps)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }
    /*
    private fun permissionGranted() = ContextCompat.checkSelfPermission (
        this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)

    private fun enableLocation() {
        if(!::mMap.isInitialized) return
    }

    private fun requestLocalPemission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)){
            Toast.makeText(this, "Acepta permisos", Toast.LENGTH_SHORT).show()
        }else{
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_CODE_LOCATION)
        }
    }*/

    override fun onMapReady(googleMap: GoogleMap) {

        mMap = googleMap

        val db = Firebase.firestore

        var long_data = findViewById<EditText>(R.id.data_longitu)
        var lat_data = findViewById<EditText>(R.id.data_latitud)


        val place = LatLng(19.50, 151.0)

        //fun locationClick(p0: Location){
        //    var long_data = longitud
        //    var Lat_data = latitud
        //}

        var txt_long: Double = place.longitude
        var txt_long_S = txt_long.toString()

        var txt_lat: Double = place.latitude
        var txt_lat_S = txt_lat.toString()

        mMap.addMarker(MarkerOptions().position(place).title("Marker in place"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(place))

        val guardar_boton = findViewById<Button>(R.id.button_guardar)

        guardar_boton.setOnClickListener{
            long_data.setText(txt_long_S)
            lat_data.setText(txt_lat_S)

            val data_Latlong = hashMapOf(
                "longitud" to txt_long_S,
                "latitud" to txt_lat_S
            )

            db.collection("location")
                .add(data_Latlong)
                .addOnSuccessListener { documentReference ->
                    Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                }
        }

        val borrar_boton = findViewById<Button>(R.id.button_borrar)

        borrar_boton.setOnClickListener{
            db.collection("location").document()
                .delete()
                .addOnSuccessListener{Log.d(TAG, "DocumentSnapshot succesfully deleted!")}
                .addOnFailureListener { e -> Log.w(TAG, "Error deleting", e)}

        }
    }
}